const TINKR_CONFIG = {
  appUrl: "https://tinkr-web-henna.vercel.app",
  apiUrl: "https://tinkr-api.vercel.app"
};
